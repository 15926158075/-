const express=require("express");
const router=express.Router();
const pool=require("../pool");
router.get("/",(req,res)=>{
    // var id=req.query.id;
    // var obj={}
    var sql="SELECT `id`, `title`, `picture_url`, `picture_type`, `type_1`, `type_2`, `man_number`, `money` FROM `muke_course`";
    pool.query(sql,(err,result)=>{
        if(err) throw err;
        res.send(result)
    });
})



module.exports=router;