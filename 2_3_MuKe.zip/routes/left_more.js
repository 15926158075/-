const express=require("express");
const router=express.Router();
const pool=require("../pool");
router.get("/",(req,res)=>{
    // var id=req.query.id;
    // var obj={}
    var sql="SELECT `uid`, `title`, `course1`, `course2`, `course3`, `course4`, `course5`, `course6`, `course7`, `course8`, `course9`, `course10`, `course11`, `course12`, `course13`, `course14`, `course15`, `course16`, `course17`, `course18`, `course19`, `img1`, `img2`, `img3`, `img4` FROM `left_more`";

   
    pool.query(sql,(err,result)=>{
        if(err) throw err;
        res.send(result)
       
    });
})



module.exports=router;