const express = require("express");
var router = express.Router();
var pool = require("../pool.js");

//用户登陆-post
router.post("/login",(req,res)=>{
    var $uname = req.body.uname;
    if(!$uname){
        res.send("用户不存在");
        return;
    }
     //获取用户密码
     var $upwd = req.body.upwd;
     if(!$upwd){
         res.send("密码错误");
         return;
     }
     var  sql =  "SELECT * FROM muke_user WHERE uname=? and upwd=?";
     pool.query(sql,[$uname,$upwd],(err,result)=>{
         if(err) throw err;

         if(result.length>0){
             res.send("登陆成功")
         }else{
             res.send("用户名或密码错误");
         }
     })
});

// 用户注册
// router.get('./ ')
router.post("/register",(req,res)=>{
    var $uname=req.body.uname;
    var $upwd=req.body.upwd;
    var sql="INSERT INTO `muke_user`(`uid`, `uname`, `upwd`) VALUES (null,?,?)"
    pool.query(sql,[$uname,$upwd],(err,result)=>{
        if(err)throw err;
        res.send({code:200,msg:"注册成功"})
    })
})


module.exports = router;