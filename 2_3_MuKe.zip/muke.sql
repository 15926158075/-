CREATE DATABASE muke CHARSET=UTF8;
USE muke;


CREATE TABLE muke_course(
   id INT PRIMARY KEY AUTO_INCREMENT, 
   title VARCHAR(64),
   picture_url  VARCHAR(255),
   picture_type VARCHAR(20),
   type_1   VARCHAR(10),
   type_2  VARCHAR(10),
   man_number INT,
   money  VARCHAR(10)
);

INSERT INTO `muke_course` VALUE(null,'全网最热Python3入门+进阶 更快上手实际开发','http://127.0.0.1:3000/img/img_center/59b8a486000107fb05400300.jpg','Python','实战','初级',501,'366.00');

INSERT INTO `muke_course` VALUE(null,'Google资深工程师深度讲解Go语言','http://127.0.0.1:3000/img/img_center/5a7127370001a8fa05400300.jpg','Go','实战','初级',333,'399.00');
INSERT INTO `muke_course` VALUE(null,'Vue2.5开发去哪网APP从零基础入门到实战项目','http://127.0.0.1:3000/img/img_center/59b8a486000107fb05400300.jpg','Vue.js','实战','中级',1300,'267.00');
INSERT INTO `muke_course` VALUE(null,'Java并发编程-高性能并发框架源码解析与实战','http://127.0.0.1:3000/img/img_center/5b4c817f0001945605400300.jpg','Java','实战','高级',999,'256.00');
INSERT INTO `muke_course` VALUE(null,'移动Web APP开发之实战美团外卖','http://127.0.0.1:3000/img/img_center/5b8510930001ab7605400300.jpg','WebAPP','实战','初级',143,'188.00');
INSERT INTO `muke_course` VALUE(null,'Vue.js源码全方位深入解析','http://127.0.0.1:3000/img/img_center/first_1.jpg','Vue.js','实战','高级',1201,'696.00');
INSERT INTO `muke_course` VALUE(null,'NLP实战TensorFlow打造聊天机器人','http://127.0.0.1:3000/img/img_center/5b6910d30001adad05400300.png','深度学习','实战','中级',91,'345.00');
INSERT INTO `muke_course` VALUE(null,'玩转数据结构 从入门到进阶','http://127.0.0.1:3000/img/img_center/5ad05dc00001eae705400300.jpg','数据结构','实战','中级',167,'496.00');
INSERT INTO `muke_course` VALUE(null,'Java RabbitMQ消息中间件技术精讲','http://127.0.0.1:3000/img/img_center/5b6015ac00011ca105400300.jpg','Spring','实战','初级',501,'366.00');
INSERT INTO `muke_course` VALUE(null,'深度学习之神经网络（CNN/RNN/GAN）','http://127.0.0.1:3000/img/img_center/5b56952600014eb005400300.jpg','深度学习','实战','初级',531,'36.00');
INSERT INTO `muke_course` VALUE(null,'OpenCV+TensorFlow人工智能图像处理','http://127.0.0.1:3000/img/img_center/5a9f4c2e00010ce205400300.jpg','人工智能','实战','初级',661,'116.00');
INSERT INTO `muke_course` VALUE(null,'2018 AWS技术峰会大数据分论坛','http://127.0.0.1:3000/img/img_center/5badc2980001ca6d06000338-240-135.jpg','云计算','实战','初级',501,'1.00');
INSERT INTO `muke_course` VALUE(null,'区块链入门与去中心化应用实战','http://127.0.0.1:3000/img/img_center/5af2a67500016b9905400300.jpg','区块链','基础','初级',101,'100.00');
INSERT INTO `muke_course` VALUE(null,'Python3入门机器学习 经典算法与运用','http://127.0.0.1:3000/img/img_center/5a39cd3f0001c09805400300.jpg','算法','实战','中级',1383,'1001.00');
INSERT INTO `muke_course` VALUE(null,'TensorFlow与Flask结合打造手写体数识别','http://127.0.0.1:3000/img/img_center/5afe7ffa00018fff06000338-240-135.jpg','深度学习','','中级',2501,'免费');
INSERT INTO `muke_course` VALUE(null,'Spark 机器学习库  大数据开发技能更进一步','http://127.0.0.1:3000/img/img_center/5b7d48a2000193a006000338.jpg','Spark','实战','中级',29,'999.00');
INSERT INTO `muke_course` VALUE(null,'区块链技术核心概念与原理讲解','http://127.0.0.1:3000/img/img_center/5ae3e5b80001818c06000338-240-135.jpg','以太坊','入门','',109,'免费');
INSERT INTO `muke_course` VALUE(null,'Spri Streaming实时流处理项目实战','http://127.0.0.1:3000/img/img_center/59f85ec90001103405400300.jpg','Sprak','实战','中级',1191,'886.00');


-- INSERT INTO `muke_course` VALUE(null,'全网最热Python3入门+进阶 更快上手实际开发','http://127.0.0.1:3000/img/img_center/59b8a486000107fb05400300.jpg','Python','实战','初级',501,'366.00');
-- INSERT INTO `muke_course` VALUE(null,'全网最热Python3入门+进阶 更快上手实际开发','http://127.0.0.1:3000/img/img_center/59b8a486000107fb05400300.jpg','Python','实战','初级',501,'366.00');
-- INSERT INTO `muke_course` VALUE(null,'全网最热Python3入门+进阶 更快上手实际开发','http://127.0.0.1:3000/img/img_center/59b8a486000107fb05400300.jpg','Python','实战','初级',501,'366.00');
-- INSERT INTO `muke_course` VALUE(null,'全网最热Python3入门+进阶 更快上手实际开发','http://127.0.0.1:3000/img/img_center/59b8a486000107fb05400300.jpg','Python','实战','初级',501,'366.00');
-- INSERT INTO `muke_course` VALUE(null,'全网最热Python3入门+进阶 更快上手实际开发','http://127.0.0.1:3000/img/img_center/59b8a486000107fb05400300.jpg','Python','实战','初级',501,'366.00');
-- INSERT INTO `muke_course` VALUE(null,'全网最热Python3入门+进阶 更快上手实际开发','http://127.0.0.1:3000/img/img_center/59b8a486000107fb05400300.jpg','Python','实战','初级',501,'366.00');
-- INSERT INTO `muke_course` VALUE(null,'全网最热Python3入门+进阶 更快上手实际开发','http://127.0.0.1:3000/img/img_center/59b8a486000107fb05400300.jpg','Python','实战','初级',501,'366.00');
-- INSERT INTO `muke_course` VALUE(null,'全网最热Python3入门+进阶 更快上手实际开发','http://127.0.0.1:3000/img/img_center/59b8a486000107fb05400300.jpg','Python','实战','初级',501,'366.00');
-- INSERT INTO `muke_course` VALUE(null,'全网最热Python3入门+进阶 更快上手实际开发','http://127.0.0.1:3000/img/img_center/59b8a486000107fb05400300.jpg','Python','实战','初级',501,'366.00');
-- INSERT INTO `muke_course` VALUE(null,'全网最热Python3入门+进阶 更快上手实际开发','http://127.0.0.1:3000/img/img_center/59b8a486000107fb05400300.jpg','Python','实战','初级',501,'366.00');
-- INSERT INTO `muke_course` VALUE(null,'全网最热Python3入门+进阶 更快上手实际开发','http://127.0.0.1:3000/img/img_center/59b8a486000107fb05400300.jpg','Python','实战','初级',501,'366.00');
-- INSERT INTO `muke_course` VALUE(null,'全网最热Python3入门+进阶 更快上手实际开发','http://127.0.0.1:3000/img/img_center/59b8a486000107fb05400300.jpg','Python','实战','初级',501,'366.00');
-- INSERT INTO `muke_course` VALUE(null,'全网最热Python3入门+进阶 更快上手实际开发','http://127.0.0.1:3000/img/img_center/59b8a486000107fb05400300.jpg','Python','实战','初级',501,'366.00');
-- INSERT INTO `muke_course` VALUE(null,'全网最热Python3入门+进阶 更快上手实际开发','http://127.0.0.1:3000/img/img_center/59b8a486000107fb05400300.jpg','Python','实战','初级',501,'366.00');
-- INSERT INTO `muke_course` VALUE(null,'全网最热Python3入门+进阶 更快上手实际开发','http://127.0.0.1:3000/img/img_center/59b8a486000107fb05400300.jpg','Python','实战','初级',501,'366.00');
-- INSERT INTO `muke_course` VALUE(null,'全网最热Python3入门+进阶 更快上手实际开发','http://127.0.0.1:3000/img/img_center/59b8a486000107fb05400300.jpg','Python','实战','初级',501,'366.00');


CREATE TABLE muke_user(
    uid  INT PRIMARY KEY AUTO_INCREMENT,
    uname VARCHAR(25),
    upwd VARCHAR(32)
);
INSERT INTO `muke_user` (`uid`, `uname`, `upwd`) VALUES 
(NULL, '15923456785', '123456789'),(NULL, '15923456787', '1234789');


CREATE TABLE left_more(
    uid  INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(50),
    course1 VARCHAR(24),
    course2 VARCHAR(24),
    course3 VARCHAR(24),
    course4 VARCHAR(24),
    course5 VARCHAR(24),
    course6 VARCHAR(24),
    course7 VARCHAR(24),
    course8 VARCHAR(24),
    course9 VARCHAR(24),
    course10 VARCHAR(24),
    course11 VARCHAR(24),
    course12 VARCHAR(24),
    course13 VARCHAR(24),
    course14 VARCHAR(24),
    course15 VARCHAR(24),
    course16 VARCHAR(24),
    course17 VARCHAR(24),
    course18 VARCHAR(24),
    course19 VARCHAR(24),
    img1 VARCHAR(255),
    img2 VARCHAR(255),
    img3 VARCHAR(255),
    img4 VARCHAR(255),

);
INSERT INTO `left_more`(`uid`, `title`, `course1`, `course2`, `course3`,
 `course4`, `course5`, `course6`, `course7`, `course8`, `course9`,
  `course10`, `course11`, `course12`, `course13`, `course14`, `course15`,
   `course16`, `course17`, `course18`, `course19`, `img1`, `img2`, `img3`, `img4`) VALUES 
(null,'前沿技术','微服务','区块链','以太坊','人工智能','机器学习','深度学习','计算机视觉',
'数据分析&挖掘',null,null,null,'区块链入门与去中心化','199.00 ·初级','区块链技术核心概念与原理',
'14.00 ·入门','Python玩转人工智能最火框架','299.00 ·中级','Python人工智能常用Numpy使用入门',
'1.00 ·入门','http://127.0.0.1:3000/img/img_lb_more/more1_1.jpg',
'http://127.0.0.1:3000/img/img_lb_more/more1_2.jpg','http://127.0.0.1:3000/img/img_lb_more/more1_3.jpg',
'http://127.0.0.1:3000/img/img_lb_more/more1_4.jpg');

INSERT INTO `left_more`(`uid`, `title`, `course1`, `course2`, `course3`,
 `course4`, `course5`, `course6`, `course7`, `course8`, `course9`,
  `course10`, `course11`, `course12`, `course13`, `course14`, `course15`,
   `course16`, `course17`, `course18`, `course19`, `img1`, `img2`, `img3`, `img4`) VALUES 
(null,'前端开发','HTML/CSS','JavaScript','Vue.js','React.js','Angular','Node.js','jQuery',
'BootStrap','Sass/Less','WbApp','前端工具','HTML5与css3实现动态网页','628.00 ·5步/29课'
,'微信小程序入门与实战','149.00 ·初级','前端跳槽必备','366.00 ·高级','前端JavaScript面试技巧',
'146.00 ·技巧','http://127.0.0.1:3000/img/img_lb_more/more2_1.jpg',
'http://127.0.0.1:3000/img/img_lb_more/more2_2.jpg','http://127.0.0.1:3000/img/img_lb_more/more2_3.jpg',
'http://127.0.0.1:3000/img/img_lb_more/more2_4.jpg');

INSERT INTO `left_more`(`uid`, `title`, `course1`, `course2`, `course3`,
 `course4`, `course5`, `course6`, `course7`, `course8`, `course9`,
  `course10`, `course11`, `course12`, `course13`, `course14`, `course15`,
   `course16`, `course17`, `course18`, `course19`, `img1`, `img2`, `img3`, `img4`) VALUES 
(null,'后端开发','Java','SpringBoot','Python','爬虫','Django','Go','PHP',
'C','C++','C#','Ruby','C++零基础入门 热门编程语言','428.00 ·3步/34课'
,'Java并发编程入门与高并发面试','299.00 ·初级','全网最热Python3入门+进阶','366.00 ·初级','最火Python3玩转实用小工具',
'166.00 ·初级','http://127.0.0.1:3000/img/img_lb_more/more3_1.jpg',
'http://127.0.0.1:3000/img/img_lb_more/more7_2.jpg','http://127.0.0.1:3000/img/img_lb_more/more3_3.jpg',
'http://127.0.0.1:3000/img/img_lb_more/more3_4.jpg');

INSERT INTO `left_more`(`uid`, `title`, `course1`, `course2`, `course3`,
 `course4`, `course5`, `course6`, `course7`, `course8`, `course9`,
  `course10`, `course11`, `course12`, `course13`, `course14`, `course15`,
   `course16`, `course17`, `course18`, `course19`, `img1`, `img2`, `img3`, `img4`) VALUES 
(null,'移动开发','Android','iOS','React native','WEEX','设计工具','设计基础','产品交互',
'功能测试','性能测试','','','Android零基础入门','499.00 ·5步/43课'
,'新浪微博资深大牛全方位剖析iOS高级面试','366.00 ·高级','BAT大牛亲授技能+Android面试技巧','288.00 ·中级',
'Android通用框架设计与完整电商APP开发','348.00 ·高级','http://127.0.0.1:3000/img/img_lb_more/more4_1.jpg',
'http://127.0.0.1:3000/img/img_lb_more/more4_2.jpg','http://127.0.0.1:3000/img/img_lb_more/more4_3.jpg',
'http://127.0.0.1:3000/img/img_lb_more/more4_4.jpg');

INSERT INTO `left_more`(`uid`, `title`, `course1`, `course2`, `course3`,
 `course4`, `course5`, `course6`, `course7`, `course8`, `course9`,
  `course10`, `course11`, `course12`, `course13`, `course14`, `course15`,
   `course16`, `course17`, `course18`, `course19`, `img1`, `img2`, `img3`, `img4`) VALUES 
(null,'算法&云计算&大数据','算法与数据结构','大数据','Hadoop','Spark','Hbase','Storm','云计算',
'AWS','Docker','KUbernetes','数学','以慕课网日志分析为例进行大数据分析','299.00 ·5步/43课'
,'轻松愉快子玩转SpringData','1.00 ·初级','系统学习Docker践行DevOps理念','289.00 ·中级',
'HBase入门','1.00 ·初级','http://127.0.0.1:3000/img/img_lb_more/more5_1.jpg',
'http://127.0.0.1:3000/img/img_lb_more/more5_2.jpg','http://127.0.0.1:3000/img/img_lb_more/more5_3.jpg',
'http://127.0.0.1:3000/img/img_lb_more/more5_4.jpg');

INSERT INTO `left_more`(`uid`, `title`, `course1`, `course2`, `course3`,
 `course4`, `course5`, `course6`, `course7`, `course8`, `course9`,
  `course10`, `course11`, `course12`, `course13`, `course14`, `course15`,
   `course16`, `course17`, `course18`, `course19`, `img1`, `img2`, `img3`, `img4`) VALUES 
(null,'运维&测试&数据库','运维','自动化运维','Linux','测试','功能&性能 测试','接口测试','MySQL',
'Redis','MongoDB','Oracle','SQL Server','阿里大牛亲授 阿里云主机(ECS)与CentOS...','499.00 ·8步/41课'
,'使用Java构建和维护接口自动化测试框架','100.00 ·中级','移动端APP UI 设计入门与实践','199.00 ·中级',
'高薪设计师必备AE移动UI动效设计','188.00 ·中级','http://127.0.0.1:3000/img/img_lb_more/more6_1.jpg',
'http://127.0.0.1:3000/img/img_lb_more/more6_2.jpg','http://127.0.0.1:3000/img/img_lb_more/more7_1.jpg',
'http://127.0.0.1:3000/img/img_lb_more/more7_2.jpg');  




CREATE TABLE shopping_cart(
    uid INT,
    uname  VARCHAR(11) PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(50),
    picture_url VARCHAR(255),
    money VARCHAR(24),
    selected INT
)

INSERT INTO `shopping_cart`(`uid`, `uname`, `title`, `picture_url`, `money`,`selected`) VALUES
 (null,"13578787765","全网最热Python3入门+进阶 更快上手实际开发",
 "http://127.0.0.1:3000/img/img_center/59b8a486000107fb05400300.jpg","366.00",0);
INSERT INTO `shopping_cart`(`uid`, `uname`, `title`, `picture_url`, `money`,`selected`) VALUES
 (null,"13578787765","Google资深工程师深度讲解Go语言
","http://127.0.0.1:3000/img/img_center/5a7127370001a8fa05400300.jpg","399.00",0);
INSERT INTO `shopping_cart`(`uid`, `uname`, `title`, `picture_url`, `money`,`selected`) VALUES
 (null,"13578787765","Vue2.5开发去哪网APP从零基础入门到实战项目",
 "http://127.0.0.1:3000/img/img_center/59b8a486000107fb05400300.jpg","256.00",0);