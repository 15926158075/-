
// 登录验证
function blur_username(){ 
    var p1 = document.getElementById('p1');
    var phone = document.getElementById('phone').value;
    if((!(/^1[34578]\d{9}$/.test(phone)))){ //||((/^[\.0-9a-z]+@([0-9a-z][0-9a-z-]+\.){1,4}[a-z]{2,3}$/.test(phone)))
       p1.innerHTML="手机号码有误，请重新输入！"; 
       p1.style.color="red";
    }else if(((/^1[34578]\d{9}$/.test(phone)))){
        p1.innerHTML="正确！"; 
        p1.style.color="green";
    }
}
function blur_upwd(){ 
    var p2 = document.getElementById('p2');
    var upwd = document.getElementById('upwd').value;
    if((!(/^(?![^a-zA-Z]+$)(?!\D+$)/.test(upwd))||upwd=="")){ 
       p2.innerHTML="密码有误，请重新输入！"; 
       p2.style.color="red";
    }else if(((/^(?![^a-zA-Z]+$)(?!\D+$)/.test(upwd)))){
        p2.innerHTML="密码正确！"; 
        p2.style.color="green";
    }
}
// 注册验证
var istrue=0;
function blur_username1(){ 
    var p3= document.getElementById('p3');
    var phone1= document.getElementById('phone1').value;
    if(phone1==""){
        p3.innerHTML="手机号不能为空！"; 
        p3.style.color="red";
        istrue=0;
    }
    else if((!(/^1[34578]\d{9}$/.test(phone1)))){ 
       p3.innerHTML="手机号码格式有误，请重新输入！"; 
       p3.style.color="red";
       istrue=0;
    }else if(((/^1[34578]\d{9}$/.test(phone1)))){
        p3.innerHTML="格式正确！"; 
        p3.style.color="green";
        istrue=1;
    }
}
var upwd=0;
function blur_upwd1(){ 
    var p4 = document.getElementById('p4');
    var upwd1 = document.getElementById('upwd1').value;
    if(upwd1==""){
        p4.innerHTML="密码不能为空！"; 
        p4.style.color="red";
        istrue=0;
        upwd==0;
    }
     else if((!(/^(?![^a-zA-Z]+$)(?!\D+$)/.test(upwd1))||upwd1=="")){ 
       p4.innerHTML="密码格式不正确，请重新输入！"; 
       p4.style.color="red";
       upwd=0;
       istrue=0;
    }else if(((/^(?![^a-zA-Z]+$)(?!\D+$)/.test(upwd1)))){
        p4.innerHTML="格式符合！"; 
        p4.style.color="green";
        upwd=1;
        istrue=1;
    }
}
function blur_upwd2(){ 
    var p5 = document.getElementById('p5');
    var upwd2 = document.getElementById('upwd2').value;
    var upwd1 = document.getElementById('upwd1').value;
    if(upwd1!=upwd2){ 
       p5.innerHTML="两次密码不一致，请重新输入！"; 
       p5.style.color="red";
       istrue=0;
    }else if((upwd==0)||upwd2==""){
        p5.innerHTML="请重新设置密码！"; 
        p5.style.color="red";
        istrue=0;
    }else if((upwd1==upwd2)&&upwd){
        p5.innerHTML="密码正确！"; 
        p5.style.color="green";
        upwd=1;
        istrue=1;
    }
}




  
var v=new Vue({
    el:"#signin",
    data:{
        // users:[
        //     {uname:"",upwd:""}
        // ],
        // currentUser:{username:"",upwd:""}
    },
    created(){
        // this.register()
    },

    methods:{
        register_ed:function(){
            if( istrue==1){
                var uname=$("#phone1").val();//获取用户名
                var upwd=$("#upwd1").val();//获取密码
                var res= axios.post(
                    "http://127.0.0.1:3000/login/register/",
                    Qs.stringify({
                        uname:uname,
                        upwd:upwd
                    })
                 
                )
                alert("注册成功！")
                istrue=0;
                
            }else{
                alert("注册失败！")
            }

    }
    },
    registered(){

    }

})




// 登录 注册转换
$("#loging").mouseenter(function(){
   
    $("#register").css("display","none");
    $("#log__in").css("display","block");
    $("#loging").css("color","#F20D0D")
    $("#registering").css("color","#050505")
})
$("#registering").mouseenter(function(){
   
    $("#log__in").css("display","none");
    $("#register").css("display","block");
    $("#registering").css("color","#F20D0D")
    $("#loging").css("color","#050505")
})


