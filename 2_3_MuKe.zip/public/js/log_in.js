$(function(){
    /*点击按钮弹框和背景层出现*/
    $('#head').click(function(){
        $('.layer').show();
        $('.log_in').show();
        center();
    });
    /*当窗口大小改变时弹框仍然位于中央*/
    $(window).resize(function(){
        center();
    });
    /*点击弹框右上角关闭按钮关闭弹框和背景层*/
    $(".delete_1").click(function(){
        $(".layer").hide();
        $(".log_in").hide();
    });
    /*使弹框位于中央*/
    function center(){
        var left = ( $(window).width() - $(".log_in").width() )/2;
        var top =( $(window).height() - $(".log_in").height() )/2;
        $('.log_in').css({'left':left,'top':top});
    }

});
window.onload=function(){
    var title = document.getElementById('head');
    move(title);
}
/*封装移动函数*/
function move( obj ){
    var onOff=false;
    var l=0,t=0,x=0,y=0;
    var parent = obj.parentNode;

    obj.onmousedown=function( event ){
        var e =event||window.event;
        x=e.clientX;
        y=e.clientY;
        l=parseInt(parent.offsetLeft);
        t=parseInt(parent.offsetTop);
        onOff=true;
        obj.style.cursor="move";    //此时鼠标形状为可移动手势
        document.onmousemove=function(event){
             if( onOff ){
                var e =event||window.event;
                parent.style.left = l+e.clientX-x+'px';
                parent.style.top = t+e.clientY-y+'px';

             }
        }
        document.onmouseup = function(){
            if(onOff){
                onOff = false;
            }
        };

    };
}

//异步对象创建
function createXhr(){
    var xhr=null;
    if(window.XMLHttpRequest){
      xhr=new XMLHttpRequest();
    }else{
      xhr=new ActiveXObject("Microsoft.XMLHttp");
    }
    return xhr;
 }
 
//异步登陆
function  login(){
    //创建异步对象
   
    var xhr = createXhr();
    //监听事件
    xhr.onreadystatechange = function(){
      if(xhr.readyState==4&&xhr.status==200){
        var res = xhr.responseText;
        alert(res);
      }
    }
    //打开链接
    xhr.open("post","/login/login",true);
    //设置消息头
    xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
    // 设置发送请求
    var $uname = document.getElementById("phone");  
    var $upwd = document.getElementById("upwd");
    var uname = $uname.value;
    var upwd  = $upwd.value;
    var url = "uname="+uname+"&upwd="+upwd;
    // console.log(url)
    xhr.send(url);
  }

