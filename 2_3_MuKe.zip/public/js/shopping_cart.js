var vm=new Vue({
    el:"#shopping_require",
    data(){
        return{
            data:[],
            money:0,
            choseall:0
        }
    },
    methods:{

        shopping(self){
            async function asy(){
                var res=await axios.get("http://127.0.0.1:3000/shopping_cart/shopping_cart");
              self.data=res.data;
            //   console.log(res.data)
              var num=0;
              for(var i=0;i<res.data.length;i++){
                num+=res.data[i].money
              }
            };
            asy();
        },
        // 总价方法
        hh:function(){
            var price=0;
            var list=this.data;
            for(var i=0;i<list.length;i++){
                if(list[i].selected){
                    price+=parseInt(list[i].money);
                }
            }
            this.money=price;
        },
        // 选中与未选中
        radios:function(index){
            var list=this.data;
            list[index].selected=!list[index].selected;
            this.hh();
            
        },
        // 全选
        chos:function(){
            var list=this.data;
            for(var i=0;i<list.length;i++){
                if(list[i].selected==0)
                this.radios(i)
            }
            // this.choseall=!this.choseall;
            // if(this.choseall==1)
            // {
            //     var list=this.data;
            //     for(var i=0;i<list.length;i++){
            //         // list[i].selected=1;
            //         this.radios(i)
            //     }
            // }
          
        }
    },
    created:function(){
        // var self=this;
        this.shopping(this)
        // this.radios()
    }
})
Vue.set(vm.data, 'b', 2);