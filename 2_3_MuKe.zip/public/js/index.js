new Vue({
    el:"#vue_clearfix",
   data:{
       res1:[
            // {title:"",picture_url:"",picture_type:"",type_1:"",type_2:""},
            // {title:"",picture_url:"",picture_type:"",type_1:"",type_2:""},
            // {title:"",picture_url:"",picture_type:"",type_1:"",type_2:""},
        ],
        res2:[
            // {title:"",picture_url:"",picture_type:"",type_1:"",type_2:""},
            // {title:"",picture_url:"",picture_type:"",type_1:"",type_2:""},
            // {title:"",picture_url:"",picture_type:"",type_1:"",type_2:""},
        ]
    },
    created(){
        (async function(self){
            var res=await axios.get("http://127.0.0.1:3000/course/");
            var ress=res.data;
            var k=[],m=[];
            for(var i=0;i<ress.length;i++){
                if(i<9){
                    k=k.concat(ress[i]);
                }else
                {
                    m=m.concat(ress[i]);
                }
            }
         self.res1=k;
         self.res2=m;
        })(this)
    }
})
