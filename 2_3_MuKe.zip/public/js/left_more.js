

new Vue({
    el:"#ad_left_more",
   data:{
    //    res1:[
    //         {
    //             title:"1",course1:"",course2:"",course3:"",course4:"",course5:"",course6:"",course7:"",
    //             course8:"",course9:"",course10:"",course11:"",course12:"",course14:"",course15:"",
    //             course16:"",course17:"",course18:"",course19:"",img1:"",img2:"",img3:"",img4:""

    //         },
    //         // {
    //         //     title:"",course1:"",course2:"",course3:"",course4:"",course5:"",course6:"",course7:"",
    //         //     course8:"",course9:"",course10:"",course11:"",course12:"",course14:"",course15:"",
    //         //     course16:"",course17:"",course18:"",course19:"",img1:"",img2:"",img3:"",img4:""
    //         // },
    //     ],
        m:{}
    },
    created(){
        (async function(self){
            var res=await axios.get("http://127.0.0.1:3000/left_more/");
            var ress=res.data;
            // console.log(ress)
        //     var k=[];
        //     for(var i=0;i<ress.length;i++){
        //         // this.res1[i]=ress[i];
        //         k=k.concat(ress[i]);
        //         console.log(k[i].title)
        //     }
        //    self.res1=k;
            // for(var i=0;i<ress.length;i++){
            //     self.res1[i]=ress[i];
            //     console.log(self.res1[i])
            // }
            $("#left_more").on("mouseenter","li",function(){
                $li=$(this);
                var i=$li.index();
                // var ad_left_more=document.getElementById("ad_left_more");
                if(i==0){
                    self.m=ress[0];
                //    console.log(self.m.title)
                }else
                if(i==1){
                    self.m=ress[1];
                //    console.log(self.m.title)
                }else
                if(i==2){
                    self.m=ress[2];
                //    console.log(self.m.title)
                }else
                if(i==3){
                    self.m=ress[3];
                //    console.log(self.m.title)
                }else
                if(i==4){
                    self.m=ress[4];
                //    console.log(self.m.title)
                }else
                if(i==5){
                    self.m=ress[5];
                //    console.log(self.m.title)
                }
            })
        })(this)
    },
    methods:{

    }
})




 // // (async function(){
                    //     // var html=``;
                    //     setTimeout({
                    //             $(document).ready(function() {
                    //                 $("#ad_left_more").each(function () {
                    //                     var myvalue = this.m.title;
                    //                     $(this).html(myvalue);
                    //                 });
                    //             })
                    //     },20)
                    //     // console.log(this.m)
                    // // )